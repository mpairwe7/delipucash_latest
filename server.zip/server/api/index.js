// Placeholder entrypoint for Bun-based API hosting; replace with Express app when ready.
console.log("Hello via Bun!");